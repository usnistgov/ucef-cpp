#include <string>

static const std::string _HelloWorld_base_version_ = "0.0.1-SNAPSHOT";