#include <string>

static const std::string _MapperEx_base_version_ = "0.0.1-SNAPSHOT";